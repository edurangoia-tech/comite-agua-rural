# Cortex Site Agent — Runbook de despliegue real

Guía operativa para llevar un servidor **Debian 13** de un sitio hasta `SITE AGENT ONLINE`,
tal como define el Sprint 1 de `docs/adr/ADR-004-site-agent.md`.

- **Resultado final:** Cortex Central muestra Site=BELISARIO, Agent=ONLINE, Version, Tailscale=CONNECTED, CPU/RAM/Disk/Uptime, Discovered assets=N, con heartbeat, telemetría y eventos recibidos.
- **Principio de red:** el agente **no abre puertos entrantes**. Solo hace HTTPS saliente a Cortex Central sobre Tailscale, autenticado con `X-API-Key` por sitio.
- **Código de este paquete:** `/opt/cortex-site-agent` (instalado por `deploy/install.sh`).

---

## 1. Arquitectura del despliegue

```
Debian 13 (sitio)                         Cortex Central (cortex.ozmar.xyz)
┌───────────────────────────────┐         ┌──────────────────────────────┐
│  cortex-agent.service          │  HTTPS  │  POST /api/site-agent/       │
│  ─ identity (site_agent_*)     │ ──────▶ │     heartbeat                 │
│  ─ collectors ping/http/server │  sobre   │  POST /api/site-agent/       │
│  ─ store-and-forward (SQLite)  │  Tailscale │     ingest (idempotente)     │
│  ─ X-API-Key por sitio         │         │  services.federation          │
└───────────────────────────────┘         └──────────────────────────────┘
   Cero puertos entrantes
```

- El agente **observa y transmite**; Cortex Central interpreta. Nunca bifurca por el nombre del poblado: las **capabilities** de `site.yaml` deciden qué collectors corren.
- Cuando Cortex no está alcanzable, los ítems se bufferizan en `queue.db` (SQLite/WAL) y se **drenan al reconectar**; la ingesta es idempotente por `event_id` (no duplica).

---

## 2. Orden del primer despliegue

Haz esto **antes** de arrancar el servicio:

1. En Cortex Central: crear la **API key por sitio** y **registrar el nodo** (`node_id` = `agent_id`).
2. En el sitio: transferir el paquete, **configurar `site.yaml`/`agent.yaml`**, colocar la key.
3. `tailscale up`.
4. `install.sh` → `verify.sh` → confirmar en Cortex Central.

> El `agent_id` es **determinista** (`site_agent_` + sha256(`site_id::site-agent`)[:16]) y se **persiste en `identity.json` la primera vez que corre** — nunca cambia después. Por eso la identidad debe quedar definida **antes** del primer arranque, y el nodo debe registrarse **antes** del primer heartbeat (si no, Cortex responde 404).

---

## 3. En Cortex Central — preparar credenciales y registro

### 3.1 Login (JWT de administrador)

```bash
TOKEN=$(curl -s -X POST https://cortex.ozmar.xyz/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@cortex.ozmar.xyz","password":"****"}' \
  | python3 -c "import sys,json;print(json.load(sys.stdin)['access_token'])")
```

### 3.2 Crear la API key por sitio (revocable individualmente)

Una key **dedicada por sitio** — nunca credenciales compartidas.

```bash
curl -s -X POST https://cortex.ozmar.xyz/api/auth/api-keys \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"name":"site_belisario_agent","permissions":"*","expires_days":365}'
```

Guarda el `key` resultante (`supo_...`) para el paso 5. Se revoca con:

```bash
curl -s -X POST https://cortex.ozmar.xyz/api/auth/api-keys/<key_id>/revoke \
  -H "Authorization: Bearer $TOKEN"
```

### 3.3 Calcular el `agent_id` determinista del sitio

```bash
python3 - <<'PY'
import hashlib
site_id = "site_belisario"
print("agent_id =", "site_agent_" + hashlib.sha256(f"{site_id}::site-agent".encode()).hexdigest()[:16])
PY
# → agent_id = site_agent_ea3d27c4279fbab9
```

### 3.4 Registrar el nodo federado

`node_id` **debe** ser el `agent_id` calculado (el agente firma su heartbeat/ingest con él).

```bash
curl -s -X POST https://cortex.ozmar.xyz/api/federation/nodes \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{
    "node_id":"site_agent_ea3d27c4279fbab9",
    "name":"Site Agent Belisario",
    "site_id":"site_belisario",
    "metadata":{"agent_version":"0.1.0"}
  }'
```

Si no hay registro previo, el heartbeat del agente responde `404 agent not registered`.

---

## 4. En el sitio — transferir el paquete

```bash
# desde Cortex Central (o donde tengas el repo)
rsync -a --exclude venv --exclude __pycache__ cortex-site-agent/ root@<sitio>:/tmp/cortex-site-agent/
```

---

## 5. En el sitio — configurar antes de arrancar

Instala primero (crea estructura, código, venv, unidad systemd y configs de ejemplo
con propietario `cortex-agent`):

```bash
cd /tmp/cortex-site-agent && sudo bash deploy/install.sh
```

> `install.sh` es **idempotente**: re-ejecutarlo nunca borra identidad, credenciales, config ni datos bufferizados. Solo escribe configs de ejemplo **si no existen**.

Ahora **detén el servicio** y escribe la configuración real **preservando el propietario** `cortex-agent`:

```bash
sudo systemctl stop cortex-agent.service

# site.yaml — identidad + capabilities + inventario local (edita a tu sitio)
sudo install -o cortex-agent -g cortex-agent -m 640 /tmp/cortex-site-agent/config/site.yaml /etc/cortex-agent/site.yaml
sudo nano /etc/cortex-agent/site.yaml      # site_id, subred LAN, inventario

# agent.yaml — URL de Cortex Central (debe resolverse desde el sitio, p.ej. por Tailscale)
sudo install -o cortex-agent -g cortex-agent -m 640 /tmp/cortex-site-agent/config/agent.yaml /etc/cortex-agent/agent.yaml
sudo nano /etc/cortex-agent/agent.yaml     # url / host / port / heartbeat_interval_s

# API key del sitio (paso 3.2) — permisos 600, propietario cortex-agent
sudo install -o cortex-agent -g cortex-agent -m 600 /dev/null /etc/cortex-agent/credentials/api_key
echo -n 'supo_...' | sudo tee /etc/cortex-agent/credentials/api_key >/dev/null
sudo chown cortex-agent:cortex-agent /etc/cortex-agent/credentials/api_key
sudo chmod 600 /etc/cortex-agent/credentials/api_key
```

`site.yaml` de referencia:

```yaml
site_id: site_belisario
site_name: Belisario Dominguez
site_type: rural

network:
  lan_subnet: 192.168.20.0/24   # CIDR real del sitio
  lan_interface: eth0
  admin_interface: tailscale0
  tailscale_up: true

capabilities:
  - ping
  - http
  - server
  # - snmp      # cuando exista un dispositivo SNMP en el sitio

inventory:
  router:
    ip: 192.168.20.1
    name: Router LAN
  olt:
    ip: 192.168.20.2
    name: OLT
  server:
    ip: 192.168.20.5
    name: Servidor local
```

---

## 6. En el sitio — Tailscale

```bash
sudo systemctl enable --now tailscaled
# autentica una sola vez (sin pre-auth key)
sudo tailscale up
# con pre-auth key (opcional, guardada fuera del repo):
sudo tailscale up --authkey="$(cat /etc/cortex-agent/credentials/tailscale_auth)"
sudo tailscale status   # verifica conectividad con Cortex Central
```

Cortex Central debe ser alcanzable desde el tailnet (IP de tailnet o `cortex.ozmar.xyz`
resolviendo al tailnet). El agente solo hace **salida** HTTPS; ningún puerto entrante.

---

## 7. En el sitio — arrancar y verificar

```bash
sudo systemctl start cortex-agent.service
sudo systemctl enable cortex-agent.service
sudo bash /opt/cortex-site-agent/deploy/verify.sh
```

`verify.sh` valida: servicio activo, proceso corriendo, configs presentes, `api_key` con permisos 600 y `cortex-agent status` ejecutable.

Estado local:

```bash
sudo /opt/cortex-site-agent/deploy/diagnose.sh     # soporte remoto, sin secretos
cortex-agent status    # o: sudo /opt/cortex-site-agent/venv/bin/python3 /opt/cortex-site-agent/__main__.py status
```

Verás `site_id`, `agent_id`, capabilities, `queue_size`, `cortex_url`, `last_transport`.

---

## 8. Confirmación en Cortex Central — `SITE AGENT ONLINE`

A los ~30 s del arranque (intervalo de heartbeat, configurable en `agent.yaml`):

```bash
# 1. El nodo está activo y reporta salud/versión/Tailscale/collectors
curl -s https://cortex.ozmar.xyz/api/federation/nodes/site_agent_ea3d27c4279fbab9 -H "Authorization: Bearer $TOKEN"

# 2. Los eventos del agente están en el timeline (heartbeat, discovered, unreachable, recovered)
curl -s "https://cortex.ozmar.xyz/api/events/recent?entity_id=site_agent_ea3d27c4279fbab9"
```

Criterios de éxito del Sprint 1 (ADR-004 §5):

- [ ] Heartbeat recibido → `status: active`, `last_seen` reciente, `health_score` poblado.
- [ ] Telemetría recibida (CPU/RAM/disco/uptime vía collector `server`).
- [ ] Eventos recibidos (`asset.discovered` / `asset.unreachable` / `asset.recovered` / `collector.failed`).
- [ ] `discovered_asset` del escaneo ARP/ping local.
- [ ] Store-and-forward verificado: cortar red → ítems en cola; reconectar → drenan sin duplicar.
- [ ] Cero puertos entrantes públicos en el sitio.

---

## 9. Operación diaria

| Acción | Comando |
|---|---|
| Ver logs | `sudo journalctl -u cortex-agent.service -f` |
| Errores recientes | `sudo journalctl -u cortex-agent.service --no-pager -n 50 \| grep -iE "error\|warn"` |
| Estado local | `cortex-agent status` |
| Diagnóstico remoto | `sudo /opt/cortex-site-agent/deploy/diagnose.sh` |
| Reiniciar agente | `sudo systemctl restart cortex-agent.service` |
| Actualizar | transferir nuevo paquete → `sudo bash /opt/cortex-site-agent/deploy/upgrade.sh` |
| Verificar tras cambios | `sudo /opt/cortex-site-agent/deploy/verify.sh` |
| Revocar key de un sitio | `POST /api/auth/api-keys/<key_id>/revoke` en Cortex Central |

**Desconexión/reconexión simulada:** `sudo systemctl stop cortex-agent.service` (o corta la
red). El agente bufferiza en `queue.db`; al reconectar `_drain()` envía todo y la ingesta
idempotente descarta duplicados por `event_id`. `verify.sh`/`diagnose.sh` reportan `queue_size`.

---

## 10. Seguridad

- **Cero puertos entrantes** públicos; tráfico solo HTTPS saliente sobre Tailscale.
- **Una API key por sitio**, revocable individualmente; secreto en `/etc/cortex-agent/credentials/api_key` (600, propietario `cortex-agent`), nunca en el repo ni en código.
- Usuario dedicado `cortex-agent` (sin shell) y unidad systemd con `ProtectSystem=strict`, `NoNewPrivileges=true`, `CapabilityBoundingSet=` vacío, `ReadWritePaths` limitados.
- `diagnose.sh` y `cortex-agent diagnose` **redactan** secretos (salida segura para soporte).
- Las métricas nuevas del agente se agregan en `scripts/operational_metrics.py` (dueño del vocabulario OAM) cuando haya datos; aquí no se duplica vocabulario.

---

## 11. Solución de problemas

| Síntoma | Causa probable | Acción |
|---|---|---|
| Heartbeat responde 404 | Nodo no registrado (o `node_id` ≠ `agent_id`) | Registrar con el `agent_id` calculado (paso 3.4) |
| `403 authentication required` | Key faltante/mal puesta | Revisar `credentials/api_key` (600, `cortex-agent`) y revocar/recrear si es necesario |
| `queue_size` crece | Cortex inalcanzable | Verificar Tailscale (`tailscale status`) y la URL de `agent.yaml` |
| Sin eventos en timeline | Colectores sin capabilities o inventario vacío | Revisar `capabilities` e `inventory` en `site.yaml` |
| `identity.json` con `agent_id` distinto al calculado | `site.yaml` cambió tras el primer arranque | El agente preserva identidad a propósito; si cambiaste de sitio, borra `identity.json` **y** re-registra el nodo |

---

## 12. Referencias

- ADR: `docs/adr/ADR-004-site-agent.md` (decisiones D1–D8, Sprint 1, ΔP = 0).
- Canal central: `routes/site_agent_api.py` (`POST /api/site-agent/heartbeat`, `POST /api/site-agent/ingest`).
- Extensiones de servicios: `services/federation.py` (`update_node_heartbeat`), `services/timeline_service.py`.
- Paquete: `cortex_site_agent/` (identity, collectors, discovery, normalization, transport, storage, security, cli).