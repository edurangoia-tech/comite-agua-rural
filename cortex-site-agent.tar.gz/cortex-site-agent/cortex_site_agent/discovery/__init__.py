"""Basic local discovery — ARP-table + ping sweep of the configured LAN.

Portable minimal version of Cortex's discovery pattern (scanner.py/arp
intelligence): discovers `discovered_asset` entries with IP/MAC when readable.
An asset may begin as `discovered_asset` and later gain capabilities, identity,
health and telemetry — no rigid classification here.
"""
import logging
import re
import subprocess

_LOG = logging.getLogger('cortex_agent.discovery')

_MAC_RE = re.compile(r'([0-9a-f]{2}[:-]){5}[0-9a-f]{2}', re.IGNORECASE)
_IP_RE = re.compile(r'\d{1,3}(?:\.\d{1,3}){3}')


def _arp_table():
    """Read ARP table from /proc/net/arp — no privileges needed."""
    assets = []
    try:
        with open('/proc/net/arp', 'r', encoding='utf-8') as fh:
            next(fh, None)  # skip header
            for line in fh:
                parts = line.split()
                if len(parts) >= 4 and parts[3] != '00:00:00:00:00:00':
                    ip, mac = parts[0], parts[3]
                    assets.append({
                        'ip': ip, 'mac': mac,
                        'state': 'discovered',
                        'source': 'arp',
                    })
    except OSError as e:
        _LOG.warning('ARP read failed: %s', e)
    return assets


def _ping_sweep(subnet, hosts=None, timeout=3):
    """Ping-sweep a /24 or explicit host list; returns reachable IPs."""
    if not hosts and not subnet:
        return []
    if not hosts:
        prefix = subnet.rsplit('.', 1)[0]
        hosts = [f'{prefix}.{i}' for i in range(1, 255)]
    found = []
    for host in hosts:
        try:
            proc = subprocess.run(
                ['ping', '-c', '1', '-W', '1', host],
                capture_output=True, text=True, timeout=timeout)
            if proc.returncode == 0:
                found.append(host)
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            continue
    return found


def discover_local(network=None):
    """Return discovered_asset list for the configured network."""
    assets = []
    seen = set()
    for a in _arp_table():
        key = a['ip']
        if key in seen:
            continue
        seen.add(key)
        assets.append({
            'asset_id': f'discovered_{a["ip"].replace(".", "_")}',
            'asset_type': 'discovered_asset',
            'ip': a['ip'],
            'mac': a['mac'],
            'state': 'discovered',
            'source': 'arp',
            'metadata': {'hostname': a.get('hostname', '')},
        })
    if network:
        for ip in _ping_sweep(network.get('subnet'), network.get('hosts')):
            if ip in seen:
                continue
            seen.add(ip)
            assets.append({
                'asset_id': f'discovered_{ip.replace(".", "_")}',
                'asset_type': 'discovered_asset',
                'ip': ip,
                'mac': None,
                'state': 'discovered',
                'source': 'ping',
                'metadata': {},
            })
    return assets