"""Transport — HTTPS client to Cortex Central over Tailscale.

Zero inbound Internet: the agent only makes outbound HTTPS calls to
https://cortex.ozmar.xyz (or the configured Cortex host) over Tailscale.
Authenticates with an X-API-Key per site. Implements store-and-forward:
when Cortex is unreachable, items are buffered locally and drained on
reconnection with idempotent dedupe (event_id/item_id).

Credential: /etc/cortex-agent/credentials/api_key (never in code or repo).
"""
import logging
import ssl
import time
from urllib import error, request

from ..storage import StoreAndForward
from ..agent.config import load_credentials

_LOG = logging.getLogger('cortex_agent.transport')

DEFAULT_CORTEX_URL = 'https://cortex.ozmar.xyz'


class CortexTransport:
    def __init__(self, config=None, queue=None):
        transport = (config or {}).get('transport', {}) or {}
        self.base_url = (transport.get('cortex', {}).get('url')
                         or DEFAULT_CORTEX_URL).rstrip('/')
        self.timeout = int(transport.get('timeout_s', 15))
        self.verify_tls = transport.get('verify_tls', True)
        self.api_key = load_credentials('api_key')
        self.queue = queue or StoreAndForward()
        self.last_success = None
        self.last_error = None

    def _headers(self):
        return {
            'Content-Type': 'application/json',
            'X-API-Key': self.api_key or '',
            'User-Agent': 'cortex-site-agent/0.1',
        }

    def _post(self, path, payload):
        if not self.api_key:
            raise RuntimeError('no api_key configured in credentials/')
        data = json_dumps(payload).encode()
        req = request.Request(f'{self.base_url}{path}', data=data,
                              headers=self._headers(), method='POST')
        ssl_ctx = ssl.create_default_context()
        if not self.verify_tls:
            ssl_ctx = ssl._create_unverified_context()
        try:
            with request.urlopen(req, timeout=self.timeout, context=ssl_ctx) as resp:
                return resp.status, resp.read().decode()
        except error.HTTPError as e:
            return e.code, e.read().decode()
        except (error.URLError, ssl.SSLError, OSError, ValueError) as e:
            self.last_error = str(e)
            raise

    # ─── Heartbeat ─────────────────────────────────────────
    def send_heartbeat(self, heartbeat_payload):
        return self._post('/api/site-agent/heartbeat', heartbeat_payload)

    # ─── Ingest batch (store-and-forward aware) ─────────────
    def ingest(self, agent_id, site_id, events=None, telemetry=None,
               inventory=None, immediate=True):
        """Send a batch, queueing items for later when Cortex is unreachable."""
        batch = {
            'agent_id': agent_id,
            'site_id': site_id,
            'events': events or [],
            'telemetry': telemetry or [],
            'inventory': inventory or [],
        }
        if immediate:
            try:
                status, body = self._post('/api/site-agent/ingest', batch)
                self.last_success = time.time()
                self.last_error = None
                return {'ok': status < 300, 'status': status, 'body': body}
            except Exception as e:
                _LOG.warning('Cortex unreachable, buffering (%s)', e)
                self._buffer_batch(batch)
                return {'ok': False, 'buffered': True}
        self._buffer_batch(batch)
        return {'ok': True, 'buffered': True}

    def _buffer_batch(self, batch):
        for event in batch.get('events', []):
            item_id = event.get('event_id') or f'evt_{abs(hash(str(event)))}'
            self.queue.enqueue(item_id, 'event', event)
        for m in batch.get('telemetry', []):
            item_id = f'meas_{m.get("asset_id")}_{m.get("measurement_type")}_{int(time.time() // 60)}'
            self.queue.enqueue(item_id, 'telemetry', m)
        for a in batch.get('inventory', []):
            item_id = f'asset_{a.get("asset_id") or abs(hash(str(a)))}'
            self.queue.enqueue(item_id, 'inventory', a)

    def drain(self, agent_id, site_id, limit=100):
        """Send buffered items; ack only on success. Returns counts."""
        sent = acked = failed = 0
        for item in self.queue.pending(limit):
            payload = item['payload']
            try:
                status, _ = self._post('/api/site-agent/ingest', {
                    'agent_id': agent_id,
                    'site_id': site_id,
                    'events': [payload] if item['kind'] == 'event' else [],
                    'telemetry': [payload] if item['kind'] == 'telemetry' else [],
                    'inventory': [payload] if item['kind'] == 'inventory' else [],
                })
                if status < 300:
                    self.queue.ack(item['item_id'])
                    acked += 1
                else:
                    self.queue.mark_attempt(item['item_id'])
                    failed += 1
                sent += 1
            except Exception:
                self.queue.mark_attempt(item['item_id'])
                failed += 1
                break
        self.last_success = time.time()
        return {'sent': sent, 'acked': acked, 'failed': failed}


def json_dumps(obj):
    import json
    return json.dumps(obj, default=str)