"""Security helpers — credential handling, redaction, minimal privileges.

Principles:
  - Zero inbound Internet: only outbound HTTPS/Tailscale connections.
  - Secrets live in /etc/cortex-agent/credentials/ (never in code or repo).
  - Logs never include credentials, API keys or SNMP communities.
  - Credentials are separated per site (one API key per site).
"""
import logging
import re

_LOG = logging.getLogger('cortex_agent.security')

_SENSITIVE_KEYS = (
    'password', 'api_key', 'token', 'secret', 'community',
    'passwd', 'auth', 'key', 'credential',
)
_SENSITIVE_VALUE_RE = re.compile(
    r'(?i)(password|api[_-]?key|token|secret|community|passwd|auth)=([^\s,;&]+)')


def redact(value, text=True):
    """Mask sensitive values in a dict or string for safe logging."""
    if text and isinstance(value, str):
        return _SENSITIVE_VALUE_RE.sub(r'\1=***', value)
    if isinstance(value, dict):
        return {k: ('***' if k.lower() in _SENSITIVE_KEYS else redact(v))
                for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [redact(v) for v in value]
    return value


def safe_log(record):
    """Return a redacted copy of a payload for logging."""
    return redact(record)


def check_credentials_permissions(path='/etc/cortex-agent/credentials'):
    """Warn if credentials directory is world-readable."""
    import os
    try:
        mode = os.stat(path).st_mode & 0o777
        if mode & 0o004:
            _LOG.warning('credentials dir %s is world-readable (0%o)', path, mode)
            return False
        return True
    except OSError:
        return False