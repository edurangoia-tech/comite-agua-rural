"""Events module — event buffer generation (heartbeat, collector failures)."""
import logging
import time

from ..normalization import make_event

_LOG = logging.getLogger('cortex_agent.events')


def heartbeat_event(identity, tailscale_state='unknown', collectors=None,
                    uptime_seconds=None, health_score=None,
                    last_sync=None):
    """Build the periodic agent.heartbeat event payload."""
    return make_event(
        identity.agent_id,
        identity.site_id,
        'agent.heartbeat',
        title='Heartbeat del agente',
        detail=f'Agent {identity.agent_id} — {identity.site_name}',
        entity_id=identity.agent_id,
        entity_type='site',
        metadata={
            'agent_version': identity.agent_version,
            'site_name': identity.site_name,
            'tailscale_state': tailscale_state,
            'uptime_seconds': uptime_seconds,
            'health_score': health_score,
            'last_successful_sync': last_sync,
            'collectors': collectors or [],
        },
    )


def collector_failed_event(identity, collector_state):
    """Build a collector.failed event from a collector state dict."""
    return make_event(
        identity.agent_id,
        identity.site_id,
        'collector.failed',
        title='Collector falló',
        detail=f'{collector_state.get("name")}: {collector_state.get("last_error")}',
        entity_id=identity.agent_id,
        entity_type='site',
        metadata={'collector': collector_state},
    )