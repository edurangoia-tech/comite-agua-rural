"""cortex-agent CLI — local observability of the agent itself.

  cortex-agent status    — clear view of local state
  cortex-agent diagnose  — remote-support diagnostics (safe, no secrets)
  cortex-agent run       — foreground loop (used by systemd)
"""
import argparse
import json
import logging
import sys


def _logging():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(name)s: %(message)s')


def _build_runtime():
    from ..agent.identity import load_or_create_identity
    from ..agent.registry import load_plugins, available_capabilities
    from ..agent.config import load_config
    from ..agent.scheduler import Scheduler
    from ..agent.lifecycle import AgentRuntime
    from ..transport import CortexTransport
    from ..storage import StoreAndForward
    config = load_config()
    identity = load_or_create_identity()
    load_plugins()
    transport = CortexTransport(config=config, queue=StoreAndForward())
    return config, identity, transport, available_capabilities()


def cmd_status(args):
    _logging()
    config, identity, transport, caps = _build_runtime()
    queue_size = transport.queue.size()
    print(f'Site Agent status')
    print(f'  site_id         : {identity.site_id}')
    print(f'  site_name       : {identity.site_name}')
    print(f'  agent_id        : {identity.agent_id}')
    print(f'  agent_version   : {identity.agent_version}')
    print(f'  capabilities    : {", ".join(identity.capabilities) or "(none)"}')
    print(f'  registered caps : {", ".join(caps) or "(none)"}')
    print(f'  queue_size      : {queue_size}')
    print(f'  cortex_url      : {config.get("transport", {}).get("cortex", {}).get("url", "https://cortex.ozmar.xyz")}')
    print(f'  last_transport  : {transport.last_success or "never"}')
    print(f'  last_error      : {transport.last_error or "-"}')
    return 0


def cmd_diagnose(args):
    _logging()
    config, identity, transport, caps = _build_runtime()
    report = {
        'site_id': identity.site_id,
        'agent_id': identity.agent_id,
        'agent_version': identity.agent_version,
        'capabilities': identity.capabilities,
        'queue_size': transport.queue.size(),
        'cortex_url': config.get('transport', {}).get('cortex', {}).get('url', 'https://cortex.ozmar.xyz'),
        'last_transport_success': transport.last_success,
        'last_transport_error': transport.last_error,
        'time': _now_iso(),
    }
    try:
        from ..collectors import server as server_mod
        report['host'] = {
            'cpu_percent': server_mod._cpu_percent(),
            'uptime_seconds': server_mod._uptime(),
            'load': list(server_mod._load_avg() or []),
            'tailscale': server_mod._tailscale_state(),
        }
    except Exception as e:
        report['host'] = {'error': str(e)}
    print(json.dumps(report, indent=2, default=str))
    return 0


def cmd_run(args):
    _logging()
    from .main import SiteAgent
    agent = SiteAgent()
    try:
        agent.run()
    except KeyboardInterrupt:
        pass
    return 0


def _now_iso():
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


def main(argv=None):
    parser = argparse.ArgumentParser(prog='cortex-agent',
                                     description='Cortex Site Agent')
    sub = parser.add_subparsers(dest='command')
    sub.add_parser('status', help='show local agent status')
    sub.add_parser('diagnose', help='emit a diagnostics report (no secrets)')
    sub.add_parser('run', help='run the agent loop in foreground')
    args = parser.parse_args(argv)

    if args.command == 'status':
        return cmd_status(args)
    if args.command == 'diagnose':
        return cmd_diagnose(args)
    if args.command == 'run':
        return cmd_run(args)
    parser.print_help()
    return 2


if __name__ == '__main__':
    sys.exit(main())