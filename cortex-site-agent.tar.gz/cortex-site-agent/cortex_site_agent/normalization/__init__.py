"""Local normalization — shape collector readings into Cortex-compatible forms.

Produces:
  measurements — evidence-style {asset_id, type, value, unit, metadata}
  events       — EVENT_CATALOG-compatible operational events (only on
                 meaningful state change; telemetry is not an event)

Event types used by the agent (append-only to EVENT_CATALOG):
  agent.heartbeat, asset.discovered, asset.unreachable, asset.recovered,
  asset.unavailable, service.down, service.recovered, link.degraded,
  collector.failed, telemetry.updated
"""
import logging
import time
import uuid

_LOG = logging.getLogger('cortex_agent.normalization')

# Reusable event metadata builders
_EVENT_ID_COUNTER = {}


def new_event_id(agent_id, prefix='evt'):
    ts = int(time.time() * 1000)
    return f'{prefix}_{agent_id[-8:]}_{ts}_{uuid.uuid4().hex[:6]}'


def normalize_measurements(agent_id, site_id, raw_measurements):
    """Tag collector measurements with identity fields."""
    return [
        {
            'asset_id': m['asset_id'],
            'asset_name': m.get('asset_name', m['asset_id']),
            'measurement_type': m['type'],
            'value': m['value'],
            'unit': m.get('unit', ''),
            'metadata': m.get('metadata', {}),
            'site_id': site_id,
            'agent_id': agent_id,
        }
        for m in raw_measurements
    ]


def make_event(agent_id, site_id, event_type, title='', detail='',
               entity_id=None, metadata=None, entity_type='site'):
    """Build an EVENT_CATALOG-compatible event envelope."""
    return {
        'event_id': new_event_id(agent_id),
        'event_type': event_type,
        'source': 'site_agent',
        'site_id': site_id,
        'agent_id': agent_id,
        'timestamp': time.strftime('%Y-%m-%dT%H:%M:%S+00:00', time.gmtime()),
        'entity_id': entity_id or agent_id,
        'entity_type': entity_type,
        'title': title,
        'detail': detail,
        'metadata': metadata or {},
    }


def transition_events(agent_id, site_id, previous_state, current_state,
                      asset_id, asset_name=''):
    """Emit state-change events only when reachability actually changes.

    Mapping per asset state:
      unknown→discovered : asset.discovered
      discovered→unreachable : asset.unreachable
      unreachable→discovered : asset.recovered
    """
    events = []
    if previous_state == current_state:
        return events
    if current_state == 'discovered' and previous_state in (None, 'unknown'):
        events.append(make_event(
            agent_id, site_id, 'asset.discovered',
            title='Activo descubierto',
            detail=asset_name or asset_id,
            entity_id=asset_id, entity_type='asset',
            metadata={'asset_id': asset_id, 'asset_name': asset_name}))
    elif current_state == 'unreachable':
        events.append(make_event(
            agent_id, site_id, 'asset.unreachable',
            title='Activo no alcanzable',
            detail=f'{asset_name or asset_id} sin respuesta',
            entity_id=asset_id, entity_type='asset',
            metadata={'asset_id': asset_id, 'asset_name': asset_name}))
    elif current_state == 'discovered' and previous_state == 'unreachable':
        events.append(make_event(
            agent_id, site_id, 'asset.recovered',
            title='Activo recuperado',
            detail=f'{asset_name or asset_id} responde de nuevo',
            entity_id=asset_id, entity_type='asset',
            metadata={'asset_id': asset_id, 'asset_name': asset_name}))
    return events