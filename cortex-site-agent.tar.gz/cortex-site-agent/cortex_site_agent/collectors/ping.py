"""Ping collector — reachability/round-trip of configured hosts.

Declares capability 'ping'. Uses the system ping binary (no privileges needed
when installed setuid). Hosts come from collectors/ping.yaml inventory.
"""
import logging
import re
import subprocess

from .base import Collector
from ..agent.config import load_collector_config

_LOG = logging.getLogger('cortex_agent.collector.ping')

_PING_TIME_RE = re.compile(r'time[=<]([\d.]+)\s*ms', re.IGNORECASE)


class PingCollector(Collector):
    capability = 'ping'
    protocol = 'icmp'
    interval_s = 60
    timeout_s = 10

    def _collect(self):
        cfg = load_collector_config('ping') or self.config.get('collectors', {}).get('ping', {})
        hosts = cfg.get('hosts', [])
        measurements = []
        for host in hosts:
            ip = host if isinstance(host, str) else host.get('ip', '')
            name = host if isinstance(host, str) else host.get('name', ip)
            if not ip:
                continue
            ok, latency_ms = self._ping(ip)
            measurements.append({
                'asset_id': f'ping_{name}',
                'asset_name': name,
                'type': 'latency',
                'value': latency_ms if ok else None,
                'unit': 'ms',
                'metadata': {'reachable': ok, 'ip': ip},
            })
        return measurements

    def _ping(self, ip):
        try:
            proc = subprocess.run(
                ['ping', '-c', '1', '-W', str(self.timeout_s), ip],
                capture_output=True, text=True, timeout=self.timeout_s + 2)
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
            _LOG.debug('ping failed for %s: %s', ip, e)
            return False, None
        if proc.returncode != 0:
            return False, None
        m = _PING_TIME_RE.search(proc.stdout)
        return True, (float(m.group(1)) if m else None)


def _register():
    from ..agent.registry import register_collector
    register_collector('ping', PingCollector)


_register()