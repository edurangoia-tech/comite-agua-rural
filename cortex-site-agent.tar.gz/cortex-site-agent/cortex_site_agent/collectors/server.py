"""Server collector — health of the Debian host running the Site Agent.

Reports CPU, RAM, disk, uptime, load, temperature (if available), network
interfaces, Tailscale status and Cortex Central connectivity. Uses psutil when
installed; falls back to /proc parsing (no privileges required).
"""
import logging
import os
import re
import socket

from .base import Collector

_LOG = logging.getLogger('cortex_agent.collector.server')

_CPU_LINE_RE = re.compile(r'^cpu\s+(.*)$')


def _read_proc(path):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return fh.read()
    except OSError:
        return ''


def _cpu_percent():
    """Read CPU usage from /proc/stat (two samples 200ms apart)."""
    def sample():
        line = _read_proc('/proc/stat')
        for row in line.splitlines():
            m = _CPU_LINE_RE.match(row)
            if m:
                parts = list(map(int, m.group(1).split()))
                idle = parts[3] + (parts[4] if len(parts) > 4 else 0)
                total = sum(parts)
                return idle, total
        return 0, 1
    i1, t1 = sample()
    import time
    time.sleep(0.2)
    i2, t2 = sample()
    dt = max(t2 - t1, 1)
    return round(100.0 * (1 - (i2 - i1) / dt), 1)


def _mem_info():
    data = _read_proc('/proc/meminfo')
    fields = {}
    for line in data.splitlines():
        parts = line.split(':')
        if len(parts) == 2:
            fields[parts[0]] = int(parts[1].strip().split()[0])  # kB
    total = fields.get('MemTotal', 0)
    available = fields.get('MemAvailable', fields.get('MemFree', 0))
    if not total:
        return None, None, None
    used = total - available
    return used, total, round(100.0 * used / total, 1)


def _disk_usage(path='/', timeout=None):
    try:
        import shutil
        usage = shutil.disk_usage(path)
        return usage.used, usage.total, round(100.0 * usage.used / usage.total, 1)
    except OSError:
        return None, None, None


def _uptime():
    try:
        with open('/proc/uptime', 'r', encoding='utf-8') as fh:
            return round(float(fh.read().split()[0]), 0)
    except (OSError, ValueError, IndexError):
        return None


def _load_avg():
    try:
        return os.getloadavg()
    except (AttributeError, OSError):
        return None


def _thermal():
    for zone in ('/sys/class/thermal/thermal_zone0/temp',
                 '/sys/class/hwmon/hwmon0/temp1_input'):
        val = _read_proc(zone).strip()
        if val:
            try:
                return round(int(val) / 1000.0, 1)
            except ValueError:
                pass
    return None


def _tailscale_state():
    """Parse tailscale status binary output; return state string."""
    try:
        import subprocess
        proc = subprocess.run(['tailscale', 'status'], capture_output=True,
                              text=True, timeout=5)
        if proc.returncode == 0 and 'tailscale' in proc.stdout.lower():
            return 'connected'
        return 'error'
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return 'unknown'


def _cortex_reachable(host, port, timeout=5):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


class ServerCollector(Collector):
    capability = 'server'
    protocol = 'system'
    interval_s = 60
    timeout_s = 15

    def _collect(self):
        used_mem, total_mem, mem_pct = _mem_info()
        used_disk, total_disk, disk_pct = _disk_usage('/')
        load = _load_avg()
        measurements = [
            self._m('cpu', 'percent', _cpu_percent(), '%'),
            self._m('mem_used', 'bytes', used_mem, 'bytes'),
            self._m('mem_total', 'bytes', total_mem, 'bytes'),
            self._m('mem_percent', 'percent', mem_pct, '%'),
            self._m('disk_used', 'bytes', used_disk, 'bytes'),
            self._m('disk_total', 'bytes', total_disk, 'bytes'),
            self._m('disk_percent', 'percent', disk_pct, '%'),
            self._m('uptime', 'seconds', _uptime(), 's'),
            self._m('load1', 'ratio', load[0] if load else None, ''),
            self._m('thermal_celsius', 'temperature', _thermal(), 'celsius'),
        ]
        ts = _tailscale_state()
        measurements.append({
            'asset_id': 'server',
            'asset_name': 'site-agent-host',
            'type': 'tailscale_state',
            'value': ts,
            'unit': '',
            'metadata': {},
        })
        cortex = (self.config.get('transport') or {}).get('cortex')
        if cortex:
            measurements.append({
                'asset_id': 'server',
                'asset_name': 'site-agent-host',
                'type': 'cortex_reachable',
                'value': _cortex_reachable(cortex.get('host', ''), int(cortex.get('port', 443))),
                'unit': '',
                'metadata': {},
            })
        return [m for m in measurements if m['value'] is not None]

    def _m(self, mtype, name, value, unit):
        return {
            'asset_id': 'server',
            'asset_name': 'site-agent-host',
            'type': mtype,
            'value': value,
            'unit': unit,
            'metadata': {},
        }


def _register():
    from ..agent.registry import register_collector
    register_collector('server', ServerCollector)


_register()