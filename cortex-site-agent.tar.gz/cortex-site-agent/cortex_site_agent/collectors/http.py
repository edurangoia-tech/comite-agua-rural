"""HTTP collector — checks HTTP(S) service availability and response time.

Declares capability 'http'. Targets come from collectors/http.yaml (list of
URLs). Used for local services (NVR UI, router UI, Starlink dish, solar
inverter UI) when reachable over the private LAN.
"""
import logging
import time
from urllib.request import Request, urlopen

from .base import Collector
from ..agent.config import load_collector_config

_LOG = logging.getLogger('cortex_agent.collector.http')


class HTTPCollector(Collector):
    capability = 'http'
    protocol = 'http'
    interval_s = 120
    timeout_s = 10

    def _collect(self):
        cfg = load_collector_config('http') or self.config.get('collectors', {}).get('http', {})
        targets = cfg.get('targets', [])
        measurements = []
        for t in targets:
            url = t if isinstance(t, str) else t.get('url', '')
            name = t if isinstance(t, str) else t.get('name', url)
            if not url:
                continue
            ok, latency_ms, http_code = self._check(url)
            measurements.append({
                'asset_id': f'http_{name}',
                'asset_name': name,
                'type': 'http_latency',
                'value': latency_ms if ok else None,
                'unit': 'ms',
                'metadata': {'reachable': ok, 'http_code': http_code, 'url': url},
            })
        return measurements

    def _check(self, url):
        req = Request(url, headers={'User-Agent': 'cortex-site-agent/0.1'})
        start = time.monotonic()
        try:
            with urlopen(req, timeout=self.timeout_s) as resp:
                latency_ms = round((time.monotonic() - start) * 1000, 1)
                return True, latency_ms, resp.status
        except Exception as e:
            _LOG.debug('http check failed %s: %s', url, e)
            return False, None, None


def _register():
    from ..agent.registry import register_collector
    register_collector('http', HTTPCollector)


_register()