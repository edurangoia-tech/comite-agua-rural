"""Collector plugin base class.

Each collector declares:
  capability   — the capability it satisfies (declared in site.yaml)
  protocol     — underlying protocol (ping/http/snmp/onvif/...)
  interval_s   — default collection interval
  timeout_s    — default timeout

A collector produces normalized measurements (dicts) and optional operational
events. It never performs business decisions — Cortex interprets.
"""
import logging
from datetime import datetime, timezone

_LOG = logging.getLogger('cortex_agent.collector')


class Collector:
    capability = 'base'
    protocol = 'base'
    interval_s = 60
    timeout_s = 10

    def __init__(self, config=None):
        self.config = config or {}
        self.name = self.__class__.__name__
        self.last_run = None
        self.last_error = None
        self.last_success = None
        self.measurements = []
        self.events = []

    # ─── Lifecycle ────────────────────────────────────────
    def start(self):
        pass

    def stop(self):
        pass

    # ─── Collect ──────────────────────────────────────────
    def collect(self):
        """Run one collection cycle. Returns list of normalized measurements."""
        try:
            self.last_run = _now()
            result = self._collect()
            self.last_success = _now()
            self.last_error = None
            return result or []
        except Exception as e:
            self.last_error = str(e)
            _LOG.error('%s collect error: %s', self.name, e)
            return []

    def _collect(self):
        raise NotImplementedError

    # ─── State ────────────────────────────────────────────
    def state(self):
        return {
            'name': self.name,
            'capability': self.capability,
            'protocol': self.protocol,
            'interval_s': self.interval_s,
            'last_run': self.last_run,
            'last_success': self.last_success,
            'last_error': self.last_error,
            'healthy': self.last_error is None,
        }


def _now():
    return datetime.now(timezone.utc).isoformat()