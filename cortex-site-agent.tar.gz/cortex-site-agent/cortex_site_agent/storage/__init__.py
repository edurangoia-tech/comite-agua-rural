"""Local store-and-forward buffer (SQLite WAL, no privileges needed).

Events and telemetry are queued locally when Cortex Central is unreachable
and drained when connectivity returns. Idempotent: every item carries a
stable item_id used for dedupe on retry.
"""
import json
import logging
import os
import sqlite3
import time

_LOG = logging.getLogger('cortex_agent.storage')

DEFAULT_DB = os.environ.get('CORTEX_AGENT_DB', '/var/lib/cortex-agent/queue.db')


class StoreAndForward:
    def __init__(self, db_path=DEFAULT_DB):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute('PRAGMA journal_mode=WAL')
        self._conn.execute('''
            CREATE TABLE IF NOT EXISTS outbox (
                item_id TEXT PRIMARY KEY,
                kind TEXT NOT NULL,
                payload TEXT NOT NULL,
                created_at REAL NOT NULL,
                attempts INTEGER DEFAULT 0,
                last_attempt REAL
            )
        ''')
        self._conn.commit()

    def enqueue(self, item_id, kind, payload):
        """Insert if not already present (idempotent)."""
        self._conn.execute(
            'INSERT OR IGNORE INTO outbox (item_id, kind, payload, created_at) '
            'VALUES (?, ?, ?, ?)',
            (item_id, kind, json.dumps(payload), time.time()))
        self._conn.commit()

    def pending(self, limit=500):
        rows = self._conn.execute(
            'SELECT item_id, kind, payload FROM outbox ORDER BY created_at LIMIT ?',
            (limit,)).fetchall()
        return [{'item_id': r[0], 'kind': r[1], 'payload': json.loads(r[2])}
                for r in rows]

    def ack(self, item_id):
        self._conn.execute('DELETE FROM outbox WHERE item_id = ?', (item_id,))
        self._conn.commit()

    def mark_attempt(self, item_id):
        self._conn.execute(
            'UPDATE outbox SET attempts = attempts + 1, last_attempt = ? '
            'WHERE item_id = ?', (time.time(), item_id))
        self._conn.commit()

    def size(self):
        return self._conn.execute('SELECT COUNT(*) FROM outbox').fetchone()[0]

    def close(self):
        self._conn.close()