"""
cortex-site-agent — Cortex Site Agent.

Local observability agent for remote Sycom sites. Observes local
infrastructure and transmits normalized telemetry/events/inventory to
Cortex Central over Tailscale+HTTPS. Cortex interprets and decides.

  SITE AGENT (observes) → Cortex Central (interprets/decides)

Architecture is capability-driven: no collector is assumed present at every
site. Configuration under /etc/cortex-agent determines capabilities.
"""
__version__ = '0.1.0'