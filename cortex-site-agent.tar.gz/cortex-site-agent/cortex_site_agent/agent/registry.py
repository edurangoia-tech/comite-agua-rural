"""Collector registry — enables collectors by declared capability.

A collector declares which capability it satisfies (e.g. 'network', 'ping',
'server'). Only collectors whose capability is enabled in site.yaml run.
Registry is the single place that maps capability → collector class.
"""
import logging

_LOG = logging.getLogger('cortex_agent.registry')

# capability → collector class (imported lazily to keep startup light)
_COLLECTOR_CLASSES = {}


def register_collector(capability, collector_class):
    """Register a collector class under a capability name."""
    _COLLECTOR_CLASSES[capability] = collector_class
    return collector_class


def available_capabilities():
    return sorted(_COLLECTOR_CLASSES.keys())


def build_collectors(enabled_capabilities, config=None):
    """Instantiate enabled collectors. Unknown capabilities are skipped with a log."""
    collectors = []
    for capability in enabled_capabilities or []:
        cls = _COLLECTOR_CLASSES.get(capability)
        if cls is None:
            _LOG.warning('Capability %s has no registered collector; skipping', capability)
            continue
        try:
            collectors.append(cls(config=config))
        except Exception as e:
            _LOG.error('Collector %s failed to build: %s', capability, e)
    return collectors


def load_plugins():
    """Import built-in collectors (each self-registers)."""
    from ..collectors import ping, http, server  # noqa: F401