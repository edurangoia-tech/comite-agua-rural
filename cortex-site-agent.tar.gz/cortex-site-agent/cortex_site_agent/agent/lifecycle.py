"""Agent lifecycle — start/stop, collector state snapshot, local health view.

Provides the state used by `cortex-agent status` and the heartbeat.
"""
import logging
import time
from datetime import datetime, timezone

_LOG = logging.getLogger('cortex_agent.lifecycle')


class AgentRuntime:
    def __init__(self, identity, collectors, transport, scheduler):
        self.identity = identity
        self.collectors = collectors
        self.transport = transport
        self.scheduler = scheduler
        self.started_at = time.time()
        self.collector_states = {c.name: None for c in collectors}
        self.last_sync = None

    def started_iso(self):
        return datetime.fromtimestamp(self.started_at, tz=timezone.utc).isoformat()

    def uptime_seconds(self):
        return int(time.time() - self.started_at)

    def record_collector(self, collector, measurements, events):
        self.collector_states[collector.name] = {
            **collector.state(),
            'measurements': len(measurements),
            'events': len(events),
        }

    def collector_snapshot(self):
        return [state or {'name': n, 'healthy': False}
                for n, state in self.collector_states.items()]

    def health_score(self):
        """0..100; degraded if any collector failed or queue has items."""
        states = self.collector_snapshot()
        if not states:
            return 100.0
        healthy = sum(1 for s in states if s.get('healthy'))
        pct = 100.0 * healthy / len(states)
        if self.transport and self.transport.queue and self.transport.queue.size() > 0:
            pct = max(0.0, pct - 10.0)
        return round(pct, 1)

    def status(self):
        return {
            'site_id': self.identity.site_id,
            'agent_id': self.identity.agent_id,
            'agent_version': self.identity.agent_version,
            'started_at': self.started_iso(),
            'uptime_seconds': self.uptime_seconds(),
            'collectors': self.collector_snapshot(),
            'health_score': self.health_score(),
            'queue_size': self.transport.queue.size() if self.transport else 0,
            'last_sync': self.last_sync,
            'last_transport_error': getattr(self.transport, 'last_error', None),
        }