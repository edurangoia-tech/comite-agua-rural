"""Main agent loop — orchestrates identity, collectors, transport, store-and-forward.

Pipeline per tick:
  scheduler → due collector.collect() → normalize → events (state changes)
  → transport.ingest (immediate or buffered) → drain queue when reachable
  → periodic heartbeat

Cortex interprets; the agent only observes and transmits.
"""
import logging
import time

from .identity import load_or_create_identity
from .registry import build_collectors, load_plugins, available_capabilities
from .scheduler import Scheduler
from .lifecycle import AgentRuntime
from .config import load_config, CONFIG_DIR
from ..collectors.base import Collector
from ..normalization import normalize_measurements
from ..events import heartbeat_event, collector_failed_event

_LOG = logging.getLogger('cortex_agent.main')

HEARTBEAT_INTERVAL_S = 30


class SiteAgent:
    def __init__(self, config=None):
        from ..transport import CortexTransport
        self.config = config or load_config()
        self.identity = load_or_create_identity()
        load_plugins()
        self.collectors = build_collectors(
            self.identity.capabilities, config=self.config)
        self.transport = CortexTransport(config=self.config)
        self.scheduler = Scheduler(self.collectors)
        self.runtime = AgentRuntime(
            self.identity, self.collectors, self.transport, self.scheduler)
        self._last_heartbeat = 0.0
        self._asset_states = {}
        self._heartbeat_interval_s = int(
            (self.config.get('transport') or {}).get(
                'heartbeat_interval_s', HEARTBEAT_INTERVAL_S))

    # ─── Collectors ─────────────────────────────────────────
    def _on_collector_tick(self, collector):
        measurements = collector.collect()
        events = []
        if collector.last_error:
            events.append(collector_failed_event(self.identity, collector.state()))
        else:
            events = self._state_change_events(measurements)
        normalized = normalize_measurements(
            self.identity.agent_id, self.identity.site_id, measurements)
        self.runtime.record_collector(collector, measurements, events)
        if normalized or events:
            self.transport.ingest(
                self.identity.agent_id, self.identity.site_id,
                events=events, telemetry=normalized,
                immediate=True)
        _LOG.info('Collector %s: %d measurements, %d events',
                  collector.name, len(measurements), len(events))

    def _state_change_events(self, measurements):
        """Emit state-change events only on reachability transitions."""
        events = []
        for m in measurements:
            asset_id = m.get('asset_id')
            if not asset_id:
                continue
            reachable = bool(m.get('value') is not None) or bool(
                m.get('metadata', {}).get('reachable'))
            current = 'discovered' if reachable else 'unreachable'
            prev = self._asset_states.get(asset_id)
            for ev in _transition_events(
                    self.identity.agent_id, self.identity.site_id,
                    prev, current, asset_id, m.get('asset_name', asset_id)):
                events.append(ev)
            self._asset_states[asset_id] = current
        return events

    # ─── Heartbeat ──────────────────────────────────────────
    def _maybe_heartbeat(self):
        if time.time() - self._last_heartbeat < self._heartbeat_interval_s:
            return
        self._last_heartbeat = time.time()
        ts = 'unknown'
        try:
            from .collectors import server
            ts = server._tailscale_state()
        except Exception:
            pass
        payload = heartbeat_event(
            self.identity,
            tailscale_state=ts,
            collectors=self.runtime.collector_snapshot(),
            uptime_seconds=self.runtime.uptime_seconds(),
            health_score=self.runtime.health_score(),
            last_sync=self.runtime.last_sync,
        )
        hb = {
            'agent_id': self.identity.agent_id,
            'site_id': self.identity.site_id,
            'agent_version': self.identity.agent_version,
            'status': 'online',
            'uptime_seconds': self.runtime.uptime_seconds(),
            'health_score': self.runtime.health_score(),
            'tailscale_state': ts,
            'collectors': self.runtime.collector_snapshot(),
            'last_successful_sync': self.runtime.last_sync,
            'metadata': {},
        }
        try:
            status, body = self.transport.send_heartbeat(hb)
            _LOG.info('Heartbeat sent: HTTP %s', status)
            if status >= 300:
                _LOG.warning('Heartbeat rejected: %s', body[:200])
        except Exception as e:
            _LOG.warning('Heartbeat buffered: %s', e)

    # ─── Drain ──────────────────────────────────────────────
    def _drain(self):
        if self.transport.queue.size() == 0:
            return
        if self._try_ping_cortex():
            result = self.transport.drain(
                self.identity.agent_id, self.identity.site_id)
            self.runtime.last_sync = time.strftime(
                '%Y-%m-%dT%H:%M:%S+00:00', time.gmtime())
            _LOG.info('Drained queue: %s', result)

    def _try_ping_cortex(self, timeout=5):
        try:
            import socket
            host = self.config.get('transport', {}).get('cortex', {}).get('host', 'cortex.ozmar.xyz')
            port = int(self.config.get('transport', {}).get('cortex', {}).get('port', 443))
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except OSError:
            return False

    # ─── Run ────────────────────────────────────────────────
    def run(self):
        _LOG.info('Site Agent %s starting (site=%s, caps=%s)',
                  self.identity.agent_id, self.identity.site_id,
                  self.identity.capabilities)
        try:
            self.scheduler.run(
                self._on_collector_tick,
                on_tick=lambda: (self._maybe_heartbeat(), self._drain()),
            )
        finally:
            self.transport.queue.close()


def _transition_events(agent_id, site_id, prev, cur, asset_id, asset_name):
    from ..normalization import transition_events
    return transition_events(agent_id, site_id, prev, cur, asset_id, asset_name)