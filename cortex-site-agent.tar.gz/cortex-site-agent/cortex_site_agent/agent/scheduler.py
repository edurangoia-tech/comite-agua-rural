"""Scheduler — runs each collector on its own interval.

Collectors declare interval_s; scheduler keeps a per-collector last-run and
runs due collectors each tick. Collectors with failures are retried on their
own cadence (no rigid global loop).
"""
import logging
import time

_LOG = logging.getLogger('cortex_agent.scheduler')


class Scheduler:
    def __init__(self, collectors, tick_s=5):
        self.collectors = collectors
        self.tick_s = tick_s
        self._next_run = {c: time.time() for c in collectors}
        self._stop = False

    def stop(self):
        self._stop = True

    def tick(self, collector_handler):
        """Run one scheduling pass; invoke handler for each due collector."""
        now = time.time()
        for c in self.collectors:
            if self._stop:
                return
            if now >= self._next_run.get(c, 0):
                interval = getattr(c, 'interval_s', 60)
                self._next_run[c] = now + interval
                try:
                    collector_handler(c)
                except Exception as e:
                    _LOG.error('Scheduler handler error for %s: %s', c.name, e)

    def run(self, collector_handler, on_stop=None, on_tick=None):
        """Blocking loop; stop via Scheduler.stop()."""
        _LOG.info('Scheduler started: %d collectors, tick=%ss',
                  len(self.collectors), self.tick_s)
        while not self._stop:
            self.tick(collector_handler)
            if on_tick:
                on_tick()
            time.sleep(self.tick_s)
        _LOG.info('Scheduler stopped')
        if on_stop:
            on_stop()