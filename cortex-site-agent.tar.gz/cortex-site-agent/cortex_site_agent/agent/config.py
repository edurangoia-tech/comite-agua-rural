"""Shared configuration loading for the Site Agent.

Layers under /etc/cortex-agent (or $CORTEX_AGENT_CONFIG):
  agent.yaml       — agent runtime config (transport, intervals, storage)
  site.yaml        — site identity + capabilities (which collectors enabled)
  credentials/     — secrets (API key, tokens) never in code/repo
  collectors/      — per-collector config (inventory, hosts, intervals)

Config is declarative; the code never branches on populated-town names.
"""
import json
import logging
import os
import sys

try:
    import yaml
except ImportError:  # minimal fallback without pyyaml
    yaml = None

_LOG = logging.getLogger('cortex_agent.config')

CONFIG_DIR = os.environ.get('CORTEX_AGENT_CONFIG', '/etc/cortex-agent')


def _read_file(path, default=None):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return fh.read()
    except FileNotFoundError:
        return default
    except OSError as e:
        _LOG.warning('Config read failed %s: %s', path, e)
        return default


def _parse(text, path):
    if text is None:
        return {}
    if yaml is not None:
        try:
            return yaml.safe_load(text) or {}
        except Exception as e:
            _LOG.warning('YAML parse failed %s: %s', path, e)
    try:
        return json.loads(text)
    except (ValueError, TypeError):
        _LOG.warning('JSON parse failed %s', path)
        return {}


def load_config(path=CONFIG_DIR):
    """Load and merge agent.yaml + site.yaml into one dict."""
    merged = {}
    for name in ('agent.yaml', 'site.yaml'):
        cfg = _parse(_read_file(os.path.join(path, name)), name)
        if isinstance(cfg, dict):
            merged.update(cfg)
    return merged


def load_collector_config(collector_name, path=CONFIG_DIR):
    """Load collector/<name>.yaml inventory/hosts."""
    cfg = _parse(
        _read_file(os.path.join(path, 'collectors', f'{collector_name}.yaml')),
        f'collectors/{collector_name}.yaml')
    return cfg if isinstance(cfg, dict) else {}


def load_credentials(credential_id, path=CONFIG_DIR):
    """Load a secret from credentials/ directory (never logs its value)."""
    value = _read_file(os.path.join(path, 'credentials', credential_id))
    return value.strip() if value else None