"""Agent identity — stable, per-site, persisted.

  site_id    canonical site identifier (site_<id>), never derived from town name
  agent_id   stable agent identifier (site_agent_<hex>) generated on first run
  version    agent package version
  capabilities  enabled capabilities from site.yaml (capability-driven)
"""
import hashlib
import json
import logging
import os
import uuid

from .config import CONFIG_DIR, load_config

_LOG = logging.getLogger('cortex_agent.identity')

IDENTITY_FILE = 'identity.json'


def _identity_path():
    return os.path.join(CONFIG_DIR, IDENTITY_FILE)


class AgentIdentity:
    def __init__(self, site_id=None, agent_id=None, capabilities=None,
                 site_name='', agent_version='0.1.0'):
        self.site_id = site_id or 'site_unknown'
        self.agent_id = agent_id or self._generate_agent_id(site_id)
        self.capabilities = capabilities or []
        self.site_name = site_name
        self.agent_version = agent_version
        self._loaded_from = None

    @staticmethod
    def _generate_agent_id(site_id):
        seed = f'{site_id}::site-agent'
        return 'site_agent_' + hashlib.sha256(seed.encode()).hexdigest()[:16]

    def to_dict(self):
        return {
            'site_id': self.site_id,
            'agent_id': self.agent_id,
            'site_name': self.site_name,
            'agent_version': self.agent_version,
            'capabilities': self.capabilities,
        }


def load_or_create_identity():
    """Load persisted identity or create one (idempotent; re-run never changes it)."""
    cfg = load_config()
    site_id = cfg.get('site_id') or 'site_unknown'
    site_name = cfg.get('site_name', '')
    capabilities = cfg.get('capabilities') or []

    path = _identity_path()
    persisted = None
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            persisted = json.load(fh)
    except (FileNotFoundError, OSError, ValueError):
        pass

    if persisted and persisted.get('agent_id'):
        identity = AgentIdentity(
            site_id=persisted.get('site_id') or site_id,
            agent_id=persisted['agent_id'],
            capabilities=persisted.get('capabilities') or capabilities,
            site_name=persisted.get('site_name') or site_name,
            agent_version=persisted.get('agent_version', '0.1.0'),
        )
    else:
        identity = AgentIdentity(site_id=site_id, capabilities=capabilities,
                                 site_name=site_name)
        try:
            with open(path, 'w', encoding='utf-8') as fh:
                json.dump(identity.to_dict(), fh, indent=2)
            _LOG.info('Identity created: %s (%s)', identity.agent_id, site_id)
        except OSError as e:
            _LOG.error('Could not persist identity: %s', e)

    return identity