# Cortex Site Agent — credentials directory
#
# Secrets live HERE, never in the repository or code.
# Permissions must be 600 and owner cortex-agent:cortex-agent.
#
#   api_key        — Cortex Central X-API-Key for THIS site (supo_* format).
#                    Created in Cortex Central per site (revocable individually).
#   tailscale_auth — optional pre-authenticated Tailscale key (if used).
#
# DO NOT COMMIT this directory. It is gitignored.