#!/usr/bin/env bash
# =============================================================================
# Cortex Site Agent — verification script.
#
# Confirms the agent is ONLINE, service active, config present, credentials
# present, and (optionally) Cortex Central acknowledges the heartbeat.
# =============================================================================
set -uo pipefail

APP_DIR="/opt/cortex-site-agent"
CONFIG_DIR="/etc/cortex-agent"
SERVICE="cortex-agent.service"

log() { echo "[cortex-agent verify] $*"; }
fail() { echo "[cortex-agent verify] ERROR: $*" >&2; exit 1; }

# 1. Service active
if systemctl is-active --quiet "$SERVICE"; then
  log "OK  service $SERVICE active"
else
  fail "service $SERVICE not active"
fi

# 2. Process running
if pgrep -f "__main__.py run" >/dev/null; then
  log "OK  agent process running"
else
  fail "no agent process"
fi

# 3. Config present
[[ -f "$CONFIG_DIR/site.yaml" ]] || fail "missing site.yaml"
[[ -f "$CONFIG_DIR/agent.yaml" ]] || fail "missing agent.yaml"
log "OK  config present (site.yaml + agent.yaml)"

# 4. Credential present
if [[ -f "$CONFIG_DIR/credentials/api_key" ]]; then
  [[ "$(stat -c %a "$CONFIG_DIR/credentials/api_key")" == "600" ]] \
    || log "WARN api_key perms not 600"
  log "OK  api_key present"
else
  fail "missing $CONFIG_DIR/credentials/api_key"
fi

# 5. Agent self-report
if "$APP_DIR/venv/bin/python3" "$APP_DIR/__main__.py" status >/dev/null 2>&1; then
  log "OK  cortex-agent status runs"
else
  fail "cortex-agent status failed"
fi

log "Verify complete. Run diagnose for remote support: $APP_DIR/diagnose.sh"
exit 0