#!/usr/bin/env bash
# =============================================================================
# Cortex Site Agent — bootstrap installer for Debian 13 (idempotent).
#
#   clean install → install → configure site → connect Tailscale →
#   register agent → verify → ONLINE
#
# Re-running this script NEVER destroys identity, credentials, config or
# pending buffered data. All state under /var/lib/cortex-agent persists.
# =============================================================================
set -euo pipefail

APP_DIR="/opt/cortex-site-agent"
CONFIG_DIR="/etc/cortex-agent"
DATA_DIR="/var/lib/cortex-agent"
LOG_DIR="/var/log/cortex-agent"
SERVICE="cortex-agent.service"
AGENT_USER="cortex-agent"

log() { echo "[cortex-agent] $*"; }
fail() { echo "[cortex-agent] ERROR: $*" >&2; exit 1; }

# --- Must run as root ----------------------------------------------
[[ "$(id -u)" -eq 0 ]] || fail "run as root (sudo)"

# --- 1. System dependencies -----------------------------------------
log "Installing system dependencies (idempotent)..."
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip tailscale iputils-ping \
    ca-certificates curl || fail "apt install failed"

# --- 2. Dedicated user ----------------------------------------------
if ! id "$AGENT_USER" >/dev/null 2>&1; then
  log "Creating user $AGENT_USER (no shell, no home)..."
  useradd --system --no-create-home --shell /usr/sbin/nologin "$AGENT_USER"
fi

# --- 3. Config + state directories ----------------------------------
install -d -o "$AGENT_USER" -g "$AGENT_USER" -m 750 "$CONFIG_DIR"
install -d -o "$AGENT_USER" -g "$AGENT_USER" -m 700 "$CONFIG_DIR/credentials"
install -d -o "$AGENT_USER" -g "$AGENT_USER" -m 750 "$CONFIG_DIR/collectors"
install -d -o "$AGENT_USER" -g "$AGENT_USER" -m 750 "$DATA_DIR"
install -d -o "$AGENT_USER" -g "$AGENT_USER" -m 750 "$LOG_DIR"

# --- 4. Code (idempotent rsync of the agent package) -----------------
log "Deploying agent code to $APP_DIR ..."
install -d -o "$AGENT_USER" -g "$AGENT_USER" "$APP_DIR"
if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete --exclude venv --exclude __pycache__ \
        "$(dirname "$0")/../" "$APP_DIR/"
else
  cp -a "$(dirname "$0")/../." "$APP_DIR/"
fi
chown -R "$AGENT_USER:$AGENT_USER" "$APP_DIR"

# --- 5. Python venv ------------------------------------------------
if [[ ! -x "$APP_DIR/venv/bin/python3" ]]; then
  log "Creating Python venv..."
  python3 -m venv "$APP_DIR/venv"
fi
"$APP_DIR/venv/bin/pip" install --quiet --upgrade pip
# Optional deps (no failure if unavailable)
"$APP_DIR/venv/bin/pip" install --quiet pyyaml 2>/dev/null || log "pyyaml not installed (JSON config fallback)"

# --- 6. Example config (only if absent — never overwrite real config) ---
if [[ ! -f "$CONFIG_DIR/site.yaml" ]]; then
  log "Writing example site.yaml (edit for this site)..."
  install -o "$AGENT_USER" -g "$AGENT_USER" -m 640 \
      "$APP_DIR/config/site.yaml" "$CONFIG_DIR/site.yaml"
  install -o "$AGENT_USER" -g "$AGENT_USER" -m 640 \
      "$APP_DIR/config/agent.yaml" "$CONFIG_DIR/agent.yaml"
  cp -a "$APP_DIR/config/collectors/." "$CONFIG_DIR/collectors/"
fi

# --- 7. systemd unit ----------------------------------------------
log "Installing systemd unit..."
install -m 644 "$APP_DIR/deploy/cortex-agent.service" \
    "/etc/systemd/system/$SERVICE"
systemctl daemon-reload

# --- 8. Tailscale (only if tailscale_up configured) -----------------
if grep -q "tailscale_up: true" "$CONFIG_DIR/site.yaml" 2>/dev/null; then
  if command -v tailscale >/dev/null 2>&1 && ! systemctl is-active --quiet tailscaled; then
    log "Starting tailscaled..."
    systemctl enable --now tailscaled
  fi
  if ! tailscale status >/dev/null 2>&1; then
    log "Tailscale not up. If a pre-auth key is present:"
    log "  tailscale up --authkey=\$(cat $CONFIG_DIR/credentials/tailscale_auth)"
  else
    log "Tailscale already connected."
  fi
fi

# --- 9. Enable + start the agent -----------------------------------
log "Enabling and starting $SERVICE ..."
systemctl enable "$SERVICE"
systemctl restart "$SERVICE"

log "Done. Verify with: sudo $APP_DIR/verify.sh"
log "Next: place API key in $CONFIG_DIR/credentials/api_key (chmod 600), then 'systemctl restart $SERVICE'."