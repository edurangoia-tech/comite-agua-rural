#!/usr/bin/env bash
# =============================================================================
# Cortex Site Agent — safe upgrade (idempotent).
#
# Re-runs install.sh which syncs code, keeps config/credentials/state.
# Then restarts the service.
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[cortex-agent] Running upgrade (safe — preserves identity, config, credentials, buffered data)..."
bash "$SCRIPT_DIR/install.sh"

systemctl restart cortex-agent.service
echo "[cortex-agent] Upgrade complete."
exit 0