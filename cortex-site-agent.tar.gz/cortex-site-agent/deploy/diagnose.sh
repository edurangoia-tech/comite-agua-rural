#!/usr/bin/env bash
# =============================================================================
# Cortex Site Agent — remote-support diagnostic.
#
# Safe output: NEVER includes credentials/secrets. Runs cortex-agent diagnose
# (which redacts) and captures service/journal context.
# =============================================================================
set -uo pipefail

APP_DIR="/opt/cortex-site-agent"
CONFIG_DIR="/etc/cortex-agent"
SERVICE="cortex-agent.service"

echo "===== cortex-agent diagnose ====="
echo
echo "--- systemd status ---"
systemctl status "$SERVICE" --no-pager 2>&1 | head -25
echo
echo "--- agent self-report (no secrets) ---"
"$APP_DIR/venv/bin/python3" "$APP_DIR/__main__.py" diagnose 2>&1 | tail -40
echo
echo "--- recent journal (errors only) ---"
journalctl -u "$SERVICE" --no-pager -n 50 2>&1 | grep -iE "error|fail|warn" | tail -20
echo
echo "--- config presence (not contents) ---"
ls -la "$CONFIG_DIR" 2>&1 | head -10
ls -la "$CONFIG_DIR/credentials" 2>&1 | sed 's/ rw-------.*/ 600 (secret present)/'
echo
echo "=== diagnose complete ==="
exit 0