#!/usr/bin/env python3
"""cortex-site-agent entry point.

Usage:
  cortex-agent status | diagnose | run
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cortex_site_agent.cli import main

if __name__ == '__main__':
    sys.exit(main())